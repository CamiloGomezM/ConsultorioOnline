/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.consultapp;

import java.sql.Date;

/**
 *
 * @author ajfon
 */
public class cita {
    private int id;
    private String titulo_cita;
    private String descripcion;
    private Date fechaCrear;
    private Date fechaCita;

    public cita() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo_cita() {
        return titulo_cita;
    }

    public void setTitulo_cita(String titulo_cita) {
        this.titulo_cita = titulo_cita;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaCrear() {
        return fechaCrear;
    }

    public void setFechaCrear(Date fechaCrear) {
        this.fechaCrear = fechaCrear;
    }

    public Date getFechaCita() {
        return fechaCita;
    }

    public void setFechaCita(Date fechaCita) {
        this.fechaCita = fechaCita;
    }

    @Override
    public String toString() {
        return "cita{" + "id=" + id + ", titulo_cita=" + titulo_cita + ", descripcion=" + descripcion + ", fechaCrear=" + fechaCrear + ", fechaCita=" + fechaCita + '}';
    }
    
}
